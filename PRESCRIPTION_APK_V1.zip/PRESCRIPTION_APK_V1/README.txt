PRESCRIPTION V1 - fresh project

This is a new project and contains no data/code from the previous prescription project.

To build the APK on GitHub:
1. Create a new GitHub repository.
2. Upload all files from this folder to the repository root.
3. Open Actions -> Build PRESCRIPTION APK.
4. Run workflow.
5. When finished, open the workflow run and download the artifact named PRESCRIPTION-v1-debug-apk.
6. Extract the artifact ZIP and install app-debug.apk on Android.
